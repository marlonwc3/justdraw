Thank you for get this typeface! 

This font was designed entirely by computer. 
If you want to donnate or make contact,
please don't doubt it. Write me to david.ignorant@gmail.com or d.espinosa.mar@gmail.com

Copyright 2011. David Espinosa Type Foundry. Just for personal use.
